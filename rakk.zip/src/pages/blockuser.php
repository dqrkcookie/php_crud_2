<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Blocked Account</title>
</head>
<style>
  h1{
    position: absolute;
    top: 45%;
    left: 50%;
    transform: translate(-50%, -50%);
    color: #4caf50;
    font-size: 3rem;
  }
</style>
<body>
    <h1>
      You have been blocked from this page!
    </h1>
</body>
</html>